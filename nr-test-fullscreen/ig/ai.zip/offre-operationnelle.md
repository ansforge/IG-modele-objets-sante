# Offre opérationnelle - Modèle des Objets de Santé (MOS) v0.1.0

* [**Table of Contents**](toc.md)
* [**Composants élémentaires**](composants_elementaires.md)
* **Offre opérationnelle**

## Offre opérationnelle

La partie Offre Opérationnelle correspond aux prestations que peut réaliser une structure et qui permettent de répondre au besoin de santé d’une personne.

  

