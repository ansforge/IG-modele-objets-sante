# Ressources opérationnelles - Modèle des Objets de Santé (MOS) v0.1.0

* [**Table of Contents**](toc.md)
* [**Composants élémentaires**](composants_elementaires.md)
* **Ressources opérationnelles**

## Ressources opérationnelles

La partie Ressources Opérationnelles regroupe les classes qui décrivent les moyens qui peuvent être mis en œuvre pour réaliser la prestation.

  

