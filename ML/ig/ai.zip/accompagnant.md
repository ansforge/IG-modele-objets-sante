# Accompagnant - Modèle des Objets de Santé (MOS) v0.1.0

* [**Table of Contents**](toc.md)
* [**Composants élémentaires**](composants_elementaires.md)
* **Accompagnant**

## Accompagnant

Toutes les entités qui protègent, aident, accompagnent la personne.

Remarque : Les classes non déployées, c’est à dire celles dont les attributs sont masqués, sont décrites dans d’autres parties (ou packages).

🔍+
🔍−
↻
⛶

  

