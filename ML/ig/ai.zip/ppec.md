# Personne prise en charge - Modèle des Objets de Santé (MOS) v0.1.0

* [**Table of Contents**](toc.md)
* [**Composants élémentaires**](composants_elementaires.md)
* **Personne prise en charge**

## Personne prise en charge

Cette partie présente les différents concepts utilisés pour définir et caractériser une personne prise en charge (personne physique). Cette partie sera complétée au fur et à mesure de l’avancement des projets en relation avec la personne prise en charge.

  

