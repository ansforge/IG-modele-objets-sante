# Dossier - Modèle des Objets de Santé (MOS) v0.1.0

* [**Table of Contents**](toc.md)
* [**Composants élémentaires**](composants_elementaires.md)
* **Dossier**

## Dossier

Ensemble de documents se rapportant à un même sujet.

Remarque : Les classes non déployées, c’est à dire celles dont les attributs sont masqués, sont décrites dans d’autres parties (ou packages).

🔍+
🔍−
↻
⛶

  

